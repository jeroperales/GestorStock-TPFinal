package Exceptions;

import java.util.InputMismatchException;

public class ErrorDeCaracterException extends InputMismatchException {
    public ErrorDeCaracterException(String mensaje){super(mensaje);}
}
