package Producto;

public enum Categoria {
    Chocolate,
    Helados,
    Cereales,
    Golosinas,
    Galletitas;
}
